from django.shortcuts import render
from .models import Db

# Create your views here.
def index(request):
    var1 = Db.objects.all().values()

    return render(request, 'index.html', {'var1': var1})

def initial(request):
    if request.method == 'POST':
        num1 = int(request.POST.get('q1'))
        num2 = int(request.POST.get('q2'))
        num3 = int(request.POST.get('q3'))
        num4 = int(request.POST.get('q4'))
        num5 = int(request.POST.get('q5'))
        num6 = int(request.POST.get('q6'))

        var2 =  Db(initial_balance=num1,current_balance=num1-num2-num3-num4-num5-num6,saving=num2,travel_expanse=num4,investment=num3,personal_expense=num5,essentials=num6)
        var2.save()
        return render(request,'index.html')
    return render(request, 'index.html')
