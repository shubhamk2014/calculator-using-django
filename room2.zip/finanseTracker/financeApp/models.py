from django.db import models

# Create your models here.
class Db(models.Model):

    initial_balance = models.IntegerField(default=0)
    current_balance = models.IntegerField(default=0)
    saving = models.IntegerField(default=0)
    travel_expanse = models.IntegerField(default=0)
    investment = models.IntegerField(default=0)
    personal_expense = models.IntegerField(default=0)
    essentials = models.IntegerField(default=0)
    

