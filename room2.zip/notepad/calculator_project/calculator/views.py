from django.shortcuts import render


def index(request):
    return render(request, 'index.html')

def add(request):
    if request.method == 'POST':
        num1 = request.POST.get('num1')
        num2 = request.POST.get('num2')
        result = int(num1) + int(num2)
        return render(request, 'result.html', {'result': result})
    return render(request, 'add.html')

def subtract(request):
    if request.method == 'POST':
        num1 = request.POST.get('num1')
        num2 = request.POST.get('num2')
        result = int(num1) - int(num2)
        return render(request, 'result.html', {'result': result})
    return render(request, 'subtract.html')

def multiply(request):
    if request.method == 'POST':
        num1 = request.POST.get('num1')
        num2 = request.POST.get('num2')
        result = int(num1) * int(num2)
        return render(request, 'result.html', {'result': result})
    return render(request, 'multiply.html')

def divide(request):
    if request.method == 'POST':
        num1 = request.POST.get('num1')
        num2 = request.POST.get('num2')
        result = int(num1) / int(num2)
        return render(request, 'result.html', {'result': result})
    return render(request, 'divide.html')
